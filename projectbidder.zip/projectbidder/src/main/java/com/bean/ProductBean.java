package com.bean;

public class ProductBean {

	private String photo;
	private String category;
	private String description;
	private String initial_price;
	private String schedule_date;
	private int b_id;
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getInitial_price() {
		return initial_price;
	}
	public void setInitial_price(String initial_price) {
		this.initial_price = initial_price;
	}
	public String getSchedule_date() {
		return schedule_date;
	}
	public void setSchedule_date(String schedule_date) {
		this.schedule_date = schedule_date;
	}
	public int getB_id() {
		return b_id;
	}
	public void setB_id(int b_id) {
		this.b_id = b_id;
	}
	
	
	
}
